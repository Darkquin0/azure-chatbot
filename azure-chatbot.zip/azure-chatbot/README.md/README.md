# Azure Chatbot using Azure Bot Service & Language Studio

## 📌 Overview
This project is a basic enterprise chatbot built using Azure services. It answers user questions based on a custom knowledge base (FAQ).

## 🛠️ Tools Used
- Azure Bot Service
- Azure Cognitive Services (Language Studio)
- Azure Web Chat

## 📂 Folder Structure
- `QnA-Knowledge-Base/` – Sample question and answer pairs
- `bot-config/` – Azure resource keys or settings (no secrets!)
- `screenshots/` – Chatbot demo screenshots

## 🚀 Features
- Easy no-code setup using Azure
- Real-time chatbot using custom Q&A data
- Can be connected to Teams, Web, Telegram, etc.

## 🧠 Future Improvements
- Add OpenAI or LUIS for smarter answers
- Add speech or voice integration
